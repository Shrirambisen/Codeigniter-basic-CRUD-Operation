<?php foreach ($stud as $std_rec){
	$rollno = $std_rec['roll_no'];
	$fname = $std_rec['firstname'];
	$mname = $std_rec['middlename'];
	$lname = $std_rec['lastname'];
	$contactno = $std_rec['contactno'];
	$email=$std_rec['email'];
	}
	?>
<?php echo validation_errors(); ?>
<?php $data = array(
        'name' => 'add_student_data',
        'class' => 'form-horizontal',
        'role' => ' form',
		'style' => 'margin-left:20em;margin-top:2em'
    );
	echo form_open('stud_rec/update_record',$data); ?>
	<div class="form-group">
        <label for="first_name" class="col-lg-2 control-label">Roll No</label>
        <div class="col-lg-4">
           <input style="border-radius:0px;" type="text" class="form-control" id="rollno" name="rollno" value="<?php echo $rollno; ?>" readonly>
        </div>
    </div>
	<div class="form-group">
        <label for="first_name" class="col-lg-2 control-label">Fisrst Name</label>
        <div class="col-lg-4">
           <input style="border-radius:0px;" type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $fname; ?>" required>
        </div>
    </div>
	<div class="form-group">
		<label for="middle_name" class="col-lg-2 control-label">Second Name</label>		
        <div class="col-lg-4">									
            <input style="border-radius:0px;" type="text" class="form-control" id="middlename" name="middlename" value="<?php echo $mname ;?>" required >
          
        </div>	
    </div>	
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Last Name</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $lname; ?>" required >
        </div>
    </div>
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Contact No</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="text" class="form-control" id="contactno" name="contactno" value="<?php echo $contactno; ?>" required >
        </div>
    </div>
	
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Email</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>" required >
        </div>
    </div>
	
	<div class="form-group">
        <div class="col-lg-2 col-lg-offset-4" >
            <input style="border-radius:0px;" type="submit" class="btn btn-primary"  value="Update">	
        </div>
    </div>
<?php echo form_close();?>
