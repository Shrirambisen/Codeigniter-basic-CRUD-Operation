
<table class="table table-striped">
<tr>
<th>Sr No</th>
<th>Roll No</th>
<th>First Name</th>
<th>Middle Name</th>
<th>Last Name</th>
<th>Contact No</th>
<th>Email</th>
<th>Delete</th>
</tr>
<?php  $i = 1; foreach ($stud as $std_rec){
	
	?>
<tr>
<td><?php echo  $i++; ?></td>
<td><?php echo $std_rec['roll_no']; ?></td>
<td><?php echo $std_rec['firstname'];?></td>
<td><?php echo $std_rec['middlename'];?></td>
<td><?php echo $std_rec['lastname'];?></td>
<td><?php echo $std_rec['contactno'];?></td>
<td><?php echo $std_rec['email'];?></td>
<td><a href="<?php echo base_url().'index.php/stud_rec/delete_record/'.$std_rec['roll_no'];?>">Delete</a></td>
</tr>
<?php
} ?>
</table>
