<?php echo validation_errors(); ?>

<?php $data = array(
        'name' => 'add_student_data',
        'class' => 'form-horizontal',
        'role' => ' form',
		'style' => 'margin-left:20em;margin-top:2em'
    );
	echo form_open('stud_rec/insert_record',$data); ?>

	<div class="form-group">
        <label for="first_name" class="col-lg-2 control-label">Fisrst Name</label>
        <div class="col-lg-4">
           <input style="border-radius:0px;" type="text" class="form-control" id="firstname" name="firstname" value="<?php if($flag==0)echo set_value('firstname'); ?>" required>
        </div>
    </div>
	<div class="form-group">
		<label for="middle_name" class="col-lg-2 control-label">Second Name</label>		
        <div class="col-lg-4">									
            <input style="border-radius:0px;" type="text" class="form-control" id="middlename" name="middlename" value="<?php if($flag==0) echo set_value('middlename'); ?>" required >
          
        </div>	
    </div>	
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Last Name</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="text" class="form-control" id="lastname" name="lastname" value="<?php if($flag==0) echo set_value('lastname'); ?>" required >
        </div>
    </div>
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Contact No</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="text" class="form-control" id="contactno" name="contactno" value="<?php if($flag==0) echo set_value('contactno'); ?>" required >
        </div>
    </div>
	
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Email</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="email" class="form-control" id="email" name="email" value="<?php if($flag==0) echo set_value('email'); ?>" required >
        </div>
    </div>
	
	<div class="form-group">
        <div class="col-lg-2 col-lg-offset-4" >
            <input style="border-radius:0px;" type="submit" class="btn btn-primary"  value="Save">	
        </div>
    </div>
<?php echo form_close();?>
