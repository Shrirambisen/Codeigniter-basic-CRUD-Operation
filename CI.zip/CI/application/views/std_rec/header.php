<!DOCTYPE html>
<html lang="en">
<head> 
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       
        <title>CodeIgniter Tutorial</title>
		
		<link href="<?php echo base_url("asset/bootstrap/css/bootstrap.min.css"); ?>" rel="stylesheet">
        <script src="<?php echo base_url("asset/bootstrap/js/bootstrap.min.js"); ?>"></script>
		
		</head>
		<style>
            

        </style>
	
<body>
<div class="container">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Student Records</a>
    </div>
    <ul class="nav navbar-nav" id="mainmenu">
      <li class="active"><?php echo anchor('sdms/home', 'Home')?></li>
	  <li><?php echo anchor('sdms/view','View Records')?></li>
      <li><?php echo anchor('sdms/add', 'Add Records')?></li>
      <li><?php echo anchor('sdms/update','Update Records')?></li>
      <li><?php echo anchor('sdms/delete','Delete Records')?></li>
    </ul>
  </div>
</nav>
<div class="panel panel-default"> 
   <div class="panel-heading"> 
     <h2><center><?php echo @$title; ?></center></h2>
   </div> 
   <div class="panel-body"> 
    
   